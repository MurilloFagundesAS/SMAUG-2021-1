﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraBGController : MonoBehaviour
{
    Camera cam;
    public Color inicial;
    public Color final;
    Color proxima;

    public AudioSource audioSource;
    public AudioClip[] audiosFundo;
    int x;
    // Start is called before the first frame update
    void Start()
    {
        cam = GetComponent<Camera>();
        cam.backgroundColor = inicial;

        audioSource = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {

        //troca a cor
        if(cam.backgroundColor == inicial){
            proxima = final;
        }
        if(cam.backgroundColor == final){
            proxima = inicial;
        }
        cam.backgroundColor = Color.Lerp(cam.backgroundColor, proxima, 0.01f);


        if(!audioSource.isPlaying){
            // x++;
            // if(x == audiosFundo.Length){
            //     x = 0;
            // }
            x = Random.Range(0, audiosFundo.Length-1);
            audioSource.clip = audiosFundo[x];
            audioSource.Play();
        }
    }
}