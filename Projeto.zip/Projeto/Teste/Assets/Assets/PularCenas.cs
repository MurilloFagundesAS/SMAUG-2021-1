﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PularCenas : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1)){
            SceneManager.LoadScene("01-Sala");
        }

        if(Input.GetKeyDown(KeyCode.Alpha2)){
            SceneManager.LoadScene("02-SalaPrincipal");
        }            

        if(Input.GetKeyDown(KeyCode.Alpha3)){
            SceneManager.LoadScene("03-Cozinha");
        }      

        if(Input.GetKeyDown(KeyCode.Alpha4)){
            SceneManager.LoadScene("04-Dispensa");
        }

        if(Input.GetKeyDown(KeyCode.Alpha5)){
            SceneManager.LoadScene("05-Dormitorios");
        }

        if(Input.GetKeyDown(KeyCode.Alpha6)){
            SceneManager.LoadScene("06-Maquinas");
        }      

        if(Input.GetKeyDown(KeyCode.Alpha7)){
            SceneManager.LoadScene("Vitoria");
        }      

    }
}
