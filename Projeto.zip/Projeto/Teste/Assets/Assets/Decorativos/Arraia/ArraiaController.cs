﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArraiaController : MonoBehaviour
{
    public Animator animator;
    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player")){
            animator.Play("ArraiaNadando", -1);
            GetComponent<BoxCollider2D>().enabled = false;
        }
    }
}
