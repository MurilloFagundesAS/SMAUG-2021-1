﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogoInicializador : MonoBehaviour
{
    public Dialogo dialogo;

    public void IniciarDialogo(){
        FindObjectOfType<DialogoGerenciador>().StartDialogo(dialogo);
        //localizando gerenciador (script), e executando funcao de start dialogo
    }
}
