﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable] //para permitir editar usando o inspector
public class Dialogo {

    public string[] nomesNPCs;

    [TextArea(1,5)]//quanatidade de linhas no inspector
    public string[] sentencas;
}
