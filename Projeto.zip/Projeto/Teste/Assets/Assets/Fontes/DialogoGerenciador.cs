﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogoGerenciador : MonoBehaviour
{

    public Text textoNome;
    public Text textoDialogo;

    public Animator animator;

    public Queue<string> sentencas;//lista FIFO, for in, for out
    public Queue<string> nomes;

    public GameObject imagemDialogo;
    public GameObject player;

    public AudioSource audioSource;
    public AudioClip audioEstatica;
    // Start is called before the first frame update
    void Awake()
    {
        textoNome = GameObject.Find("Canvas").transform.GetChild(4).GetChild(0).GetComponent<Text>();
        textoDialogo = GameObject.Find("Canvas").transform.GetChild(4).GetChild(1).GetComponent<Text>();
        animator = GameObject.Find("Canvas").transform.GetChild(4).GetComponent<Animator>();
        imagemDialogo = GameObject.Find("Canvas").transform.GetChild(4).gameObject;
        player = GameObject.Find("Player");

        sentencas = new Queue<string>();
        nomes = new Queue<string>();

        audioSource = GetComponent<AudioSource>();
        DontDestroyOnLoad(transform.gameObject);
    }

    private void Update() {
        if(Input.GetButtonDown("Fire1") && imagemDialogo.activeSelf == true){
            FindObjectOfType<DialogoGerenciador>().ProximaSentenca();
        }
        if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)){
            FindObjectOfType<DialogoGerenciador>().FinalizaDialogo();
        }

        if(SceneManager.GetActiveScene().name == "GameOver" || SceneManager.GetActiveScene().name == "Vitoria"){
            Destroy(transform.gameObject);
        }
    }

    public void StartDialogo(Dialogo dialogo){
        imagemDialogo.SetActive(true);
        animator.SetBool("Aberto", true);

        // Debug.Log("Iniciando Dialogo");
        //textoNome.text = dialogo.nomeNPC;

        sentencas.Clear();//funcao do queue
        nomes.Clear(); //limpando fila

        foreach(string sentenca in dialogo.sentencas){
            sentencas.Enqueue(sentenca);
        }
        foreach(string nome in dialogo.nomesNPCs){
            nomes.Enqueue(nome);
        }

        audioSource.clip = audioEstatica;
        audioSource.Play();
        ProximaSentenca();
    }

    public void ProximaSentenca(){
        if(sentencas.Count == 0){
            FinalizaDialogo();
            return;
        }

        textoNome.text = nomes.Dequeue();
        string sentenca = sentencas.Dequeue();//recebe a sentença da fila
        // textoDialogo.text = sentenca;
        //Debug.Log(sentenca);
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentenca));
    }

    //usando corrotina pra escrever o texto devagar/letra por letra
    IEnumerator TypeSentence(string sentenca){
        textoDialogo.text = "";

        foreach(char letra in sentenca.ToCharArray()){//converte string num array de caracteres
            textoDialogo.text += letra;
            yield return null;
        }
    }

    public void FinalizaDialogo(){
        player.GetComponent<PlayerController>().enabled = true;
        if(SceneManager.GetActiveScene().name != "06-Maquinas"){
            animator.SetBool("Aberto", false);
            imagemDialogo.SetActive(false);
            Debug.Log("Fim da conversa");
            audioSource.Stop();
        }
        else{
            Debug.Log("Fim do jogo");
            SceneManager.LoadScene("Vitoria");
        }

    }

}
