﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IniciaDialogoController : MonoBehaviour
{

    public Dialogo dialogo;

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player")){
            FindObjectOfType<DialogoGerenciador>().StartDialogo(dialogo);
            other.GetComponent<PlayerController>().rb.velocity = Vector2.zero;
            other.GetComponent<PlayerController>().skin.GetComponent<Animator>().SetBool("Correr", false);
            other.GetComponent<PlayerController>().enabled = false;
        }
    }

    private void OnTriggerExit2D(Collider2D other) {
        if(other.CompareTag("Player")){
            GetComponent<BoxCollider2D>().enabled = false;
        }
    }
}
