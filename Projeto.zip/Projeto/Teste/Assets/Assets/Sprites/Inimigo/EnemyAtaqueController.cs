﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAtaqueController : MonoBehaviour
{
    public void MatarPlayer(){
        transform.parent.GetComponent<EnemyController>().player.GetComponent<PlayerController>().vivo = false;
        transform.parent.GetComponent<DialogoInicializador>().IniciarDialogo();
        this.enabled = false;
    }
}
