using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnemyController : MonoBehaviour
{

    public Transform skin;
    public Transform a;
    public Transform b;

    public bool ultimaPos;

    public Transform player;

    public float vel;
    public bool detectou;
    public bool praDireita;
    public bool parede;

    Vector2 origem;
    Vector2 direcao;
    // Start is called before the first frame update
    void Awake()
    {
        player = GameObject.Find("Player").transform;
        detectou = false;
    }

    // Update is called once per frame
    void Update()
    {

        if(detectou == false){
            if(praDireita){
                transform.rotation = Quaternion.Euler(0, 180, 0);
                direcao = -transform.right;
                if(Vector2.Distance(transform.position, a.transform.position) <= 0.1f){
                    praDireita = false;
                }
                transform.position = Vector2.MoveTowards(transform.position, a.transform.position, vel * Time.deltaTime);
            }else{
                transform.rotation = Quaternion.Euler(0, 0, 0);
                direcao = -transform.right;
                if(Vector2.Distance(transform.position, b.transform.position) <= 0.1f){
                    praDireita = true;
                }
                transform.position = Vector2.MoveTowards(transform.position, b.transform.position, vel * Time.deltaTime);
            }
        }
        else{
                transform.position = Vector2.MoveTowards(transform.position, new Vector2 (player.transform.position.x, transform.position.y), vel * Time.deltaTime);
        }


        RaycastHit2D hit = Physics2D.Raycast(new Vector2 (transform.position.x, transform.position.y+1), direcao, 7f);
        Debug.DrawRay(new Vector2 (transform.position.x, transform.position.y+1), direcao*7f, Color.red);
        if(hit.collider != null){
            if(hit.collider.gameObject.CompareTag("Player") && player.GetComponent<PlayerController>().escondido == true){
                Debug.Log("Achou " + hit.collider.name);
                vel = 10f;
                detectou = true;
            }
            else{
                vel = 5f;
                detectou = false;    
            }
        }
        else{
            vel = 5f;
            detectou = false;
        }

    }

    public void EnemyPosition(){
        if(transform.position.x < a.transform.position.x && transform.position.x > b.transform.position.x){
            praDireita = ultimaPos;
            Debug.Log("Executou");
        }
        else{
            praDireita = !praDireita;
            Debug.Log("Não");
        }
    }

    private void OnTriggerStay2D(Collider2D other) {
        if(other.gameObject.CompareTag("Player") && player.GetComponent<PlayerController>().escondido == true){
            skin.GetComponent<Animator>().Play("MonstroAtacando", -1);
            Debug.Log("Colidiu com player");
            GetComponent<EnemyController>().enabled = false;
        }            
    }
}
