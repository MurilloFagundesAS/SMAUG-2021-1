﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectorController : MonoBehaviour
{
    public AudioSource audioSource;

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player") && transform.parent.GetComponent<EnemyController>().detectou == true){
            audioSource.Play();
            transform.parent.GetComponent<EnemyController>().ultimaPos = transform.parent.GetComponent<EnemyController>().praDireita;
        }
    }

    private void OnTriggerExit2D(Collider2D other) {
        if(other.CompareTag("Player") && transform.parent.GetComponent<EnemyController>().detectou == true){
            transform.parent.GetComponent<EnemyController>().EnemyPosition();
        }
    }
}
