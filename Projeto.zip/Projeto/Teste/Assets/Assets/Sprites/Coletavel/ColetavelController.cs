﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColetavelController : MonoBehaviour
{

    public string nomeItem;

}
