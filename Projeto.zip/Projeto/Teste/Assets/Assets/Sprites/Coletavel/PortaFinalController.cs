﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortaFinalController : MonoBehaviour
{
    public string nomeSenha;

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player")){
            if(other.GetComponent<PlayerController>().item != null){
                if(other.GetComponent<PlayerController>().item == nomeSenha){
                    other.GetComponent<PlayerController>().rb.velocity = Vector2.zero;
                    other.GetComponent<PlayerController>().skin.GetComponent<Animator>().SetBool("Correr", false);
                    other.GetComponent<PlayerController>().enabled = false;
                    GetComponent<DialogoInicializador>().IniciarDialogo();
                }
            }
        }
    }
}
