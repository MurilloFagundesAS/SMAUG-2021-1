﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PortaColetavelController : MonoBehaviour
{

    public string nomeSenha;
    public string proximoLevel;

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player")){
            if(other.GetComponent<PlayerController>().item != null){
                if(other.GetComponent<PlayerController>().item == nomeSenha){
                    SceneManager.LoadScene(proximoLevel);
                }
            }
        }
    }
}
