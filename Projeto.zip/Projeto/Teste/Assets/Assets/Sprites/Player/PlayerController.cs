﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb;
    Vector2 vel;

    public GameObject gameOver;

    public Transform skin;
    public Transform detectorPulo;

    public bool vivo;

    public bool escondido;
    public bool esconderijo;

    public Transform pauseScreen;

    public GameObject hud;
    public string item;

    string sceneAtual;

    public float alturaPulo;
    public float velocidadeX;

    // Start is called before the first frame update
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        
        vivo = true;

        escondido = true;
        esconderijo = false;

        sceneAtual = SceneManager.GetActiveScene().name;
        DontDestroyOnLoad(transform.gameObject);
    }

    // Update is called once per frame
    void Update()
    {



        //mudança de cena
        if(!sceneAtual.Equals(SceneManager.GetActiveScene().name)){
            if(SceneManager.GetActiveScene().name == "GameOver" || SceneManager.GetActiveScene().name == "Vitoria"){
                DestroyPlayer();
            }
            
            item = "";
            hud.GetComponent<Image>().sprite = null;
            hud.SetActive(false);

            sceneAtual = SceneManager.GetActiveScene().name;
            transform.position = GameObject.Find("Spawn").transform.position;
        }


        //inicializando do Game Over
        if(!vivo){
            skin.GetComponent<Animator>().Play("PlayerParado", -1);
            skin.GetComponent<Animator>().enabled = false;
            vel = Vector2.zero;
            gameOver.SetActive(true);
            escondido = false;
        }

        //pausa
        if(Input.GetKeyDown(KeyCode.P)){
            pauseScreen.GetComponent<PauseController>().enabled = !pauseScreen.GetComponent<PauseController>().enabled;
        }

        //escondendo
        if(Input.GetButtonDown("Fire1") && esconderijo == true){
            if(escondido == true){
                skin.GetComponent<Animator>().Play("PlayerEscondido", -1); // aguachando/escondendo
                Invoke("Esconder", 0.07f);
            }
            else{
                skin.GetComponent<Animator>().Play("PlayerEscondido", -1);
                Invoke("Esconder", 0.07f);
            }
        }

        
        if(escondido){
            //sistema de pulo
            if(Input.GetButtonDown("Jump") && detectorPulo.GetComponent<CollisorPuloController>().permissao == true){
                skin.GetComponent<Animator>().Play("PlayerPulando", -1);
                rb.velocity = new Vector2(0, 0);
                rb.AddForce(new Vector2(0, alturaPulo), ForceMode2D.Impulse);
            }

            //mudando direção ("flipagem") do personagem
            if(Input.GetAxisRaw("Horizontal") != 0){
                skin.GetComponent<Animator>().SetBool("Correr", true);
                skin.localScale = new Vector3(Input.GetAxisRaw("Horizontal")*0.3f, 0.2f, 1);
            }else{
                skin.GetComponent<Animator>().SetBool("Correr", false);
            }
            vel = new Vector2(Input.GetAxisRaw("Horizontal")*velocidadeX, rb.velocity.y);
        }
        else{
            // rb.velocity = new Vector2(0, 0);
            vel = Vector2.zero;
        }

        rb.velocity = vel;
    }

    //setando velocidade no Fixed para ser igual em todos os consoles
    // private void FixedUpdate() {
    //     rb.velocity = vel;
    // }

    //ocultando o player do monstro
    private void Esconder(){
        escondido = !escondido;
        skin.GetComponent<Renderer>().enabled = escondido;
    }

    //conferindo colisão com item coletavel
    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Item")){
            hud.SetActive(true);

            item = other.GetComponent<ColetavelController>().nomeItem;

            hud.GetComponent<Image>().sprite = other.GetComponent<SpriteRenderer>().sprite;
            Destroy(other.gameObject);
        }
    }

    public void DestroyPlayer(){
        Destroy(transform.gameObject);
    }

}
