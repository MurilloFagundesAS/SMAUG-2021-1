﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisorPuloController : MonoBehaviour
{
    public bool permissao;
    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Floor")){
            permissao = true;
        }
    }
    private void OnTriggerExit2D(Collider2D other) {
        if(other.CompareTag("Floor")){
            permissao = false;
        }
    }
}
