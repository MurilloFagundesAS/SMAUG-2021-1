﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EsconderijoCollider : MonoBehaviour
{

        public Transform botaoSpace;
        public Text textoBotao;


    private void Start() {
        botaoSpace = GameObject.Find("Canvas").transform.GetChild(3);
        textoBotao = botaoSpace.GetComponentInChildren<Text>();
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player")){
            other.GetComponent<PlayerController>().esconderijo = true;
        }
    }

    private void OnTriggerStay2D(Collider2D other) {
        if(other.CompareTag("Player")){
            if(other.GetComponent<PlayerController>().escondido == true){
                textoBotao.text = "Esconder";
            }
            else{
                textoBotao.text = "Sair";
            }

            botaoSpace.gameObject.SetActive(true);
        }
    }
    private void OnTriggerExit2D(Collider2D other) {
        if(other.CompareTag("Player")){
            other.GetComponent<PlayerController>().esconderijo = false;
            botaoSpace.gameObject.SetActive(false);
        }
    }
}
