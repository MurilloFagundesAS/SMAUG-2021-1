﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AlavancaController : MonoBehaviour
{
    public bool comando;
    public Transform botaoSpace;
    public Text textoBotao;

    public AudioSource audioSource;
    public AudioClip audioAlavanca;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();

        botaoSpace = GameObject.Find("Canvas").transform.GetChild(3);
        textoBotao = botaoSpace.GetComponentInChildren<Text>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerStay2D(Collider2D other) {
        if(other.CompareTag("Player") && Input.GetButtonDown("Fire1")){
            audioSource.PlayOneShot(audioAlavanca, 1);
            comando = true;
            transform.localScale = new Vector3(-1, 1, 1);
            this.enabled = false;

            botaoSpace.gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.CompareTag("Player") && comando == false){
            botaoSpace.gameObject.SetActive(true);
            textoBotao.text = "Ativar";
        }
    }

    private void OnTriggerExit2D(Collider2D other) {
        if(other.CompareTag("Player")){
            botaoSpace.gameObject.SetActive(false);
        }        
    }
}
