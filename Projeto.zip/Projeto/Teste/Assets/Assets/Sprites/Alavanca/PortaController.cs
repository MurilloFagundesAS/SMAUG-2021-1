﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class PortaController : MonoBehaviour
{

    public Transform[] itens;
    public bool[] alavancas;

    public Sprite portaAberta;

    public AudioSource audioSource;
    public AudioClip audioPorta;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        alavancas = new bool[itens.Length];
    }

    // Update is called once per frame
    void Update()
    {
        int x = 0;
        foreach(Transform alavanca in itens){
            alavancas[x] = alavanca.GetComponent<AlavancaController>().comando;
            x++;
        }


        if(alavancas.Contains(false)){
            GetComponent<BoxCollider2D>().enabled = true;
        }
        else{
            GetComponent<BoxCollider2D>().enabled = false;
            audioSource.PlayOneShot(audioPorta, 1);
            GetComponentInChildren<SpriteRenderer>().sprite = portaAberta;
            this.enabled = false;
        }
    }
}
