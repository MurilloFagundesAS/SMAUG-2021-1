﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenusController : MonoBehaviour
{
    public GameObject tutorialPanel;
    public GameObject creditosPanel;
    
    public AudioSource audioSource;
    public AudioClip audioClickBotao;
    private void Start() {
        audioSource = GetComponent<AudioSource>();
    }

    public void PlayGame(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        SceneManager.LoadScene("01-Sala");
    }

    public void ExitGame(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        Application.Quit();
    }

    public void EnterMenu(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        SceneManager.LoadScene("Menu");
    }

    public void Tutorial(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        tutorialPanel.SetActive(!tutorialPanel.activeSelf);
    }

    public void Creditos(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        creditosPanel.SetActive(!creditosPanel.activeSelf);
    }

    public void Opcoes(){
        audioSource.PlayOneShot(audioClickBotao, 1);
        SceneManager.LoadScene("Opcoes");
    }

}
