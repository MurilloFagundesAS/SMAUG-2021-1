﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class OpcoesController : MonoBehaviour
{
    public AudioMixer musicaMixer;
    public AudioMixer efeitosMixer;
    public AudioMixer protagonistaMixer;
    public AudioMixer monstrosMixer;

    public Text musicaVolumeTexto;
    public Text efeitosVolumeTexto;
    public Text protagonistaVolumeTexto;
    public Text monstrosVolumeTexto;

    public GameObject sliderMusica;
    public GameObject sliderEfeitos;
    public GameObject sliderProtagonista;
    public GameObject sliderMonstros;

    private void Awake() {
        sliderProtagonista.GetComponent<Slider>().value = 0;
        sliderMonstros.GetComponent<Slider>().value = 5f;
        sliderEfeitos.GetComponent<Slider>().value = 0f;
        sliderMusica.GetComponent<Slider>().value = 0f;

        protagonistaVolumeTexto.text = "Personagem: " +  sliderProtagonista.GetComponent<Slider>().value.ToString("F0") + "%";
        monstrosVolumeTexto.text = "Monstros: " +  sliderMonstros.GetComponent<Slider>().value.ToString("F0") + "%";
        efeitosVolumeTexto.text = "Efeitos: " +  sliderEfeitos.GetComponent<Slider>().value.ToString("F0") + "%";
        musicaVolumeTexto.text = "Musica: " +  sliderMusica.GetComponent<Slider>().value.ToString("F0") + "%";
    }

    public void MudarVolumeMusica(float volume){
        musicaMixer.SetFloat("Volume", volume);
        musicaVolumeTexto.text = "Musica: " + volume.ToString("F0") + "%";
    }

    public void MudarVolumeEfeitos(float volume){
        efeitosMixer.SetFloat("Volume", volume);
        efeitosVolumeTexto.text = "Efeitos: " + volume.ToString("F0") + "%";
    }

    public void MudarVolumeProtagonista(float volume){
        protagonistaMixer.SetFloat("Volume", volume);
        protagonistaVolumeTexto.text = "Personagem: " + volume.ToString("F0") + "%";
    }

    public void MudarVolumeMonstros(float volume){
        monstrosMixer.SetFloat("Volume", volume);
        monstrosVolumeTexto.text = "Monstros: " + volume.ToString("F0") + "%";
    }
}
