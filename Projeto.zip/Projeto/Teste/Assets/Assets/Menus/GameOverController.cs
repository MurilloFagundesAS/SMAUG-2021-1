﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverController : MonoBehaviour
{
    void OnEnable(){
        GetComponent<CanvasGroup>().blocksRaycasts = true; //ativa raycasts, permitindo interação
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<CanvasGroup>().alpha += Time.deltaTime * 0.5f; //aumenta alfa com o tempo
       
       if(GetComponent<CanvasGroup>().alpha == 1){
           this.enabled = false;
       }
    }

    private void OnDisable() {
        SceneManager.LoadScene("GameOver");
    }
}
