﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseController : MonoBehaviour
{

    public Transform player;

    private void OnEnable() {
        GetComponent<CanvasGroup>().alpha = 1;
        GetComponent<CanvasGroup>().blocksRaycasts = true;
        Time.timeScale = 0f;
        /*
        Time.timeScale gerencia o tempo de processamento do jogo, mexer nele
        altera a forma como os gameObjects se movem. O valor 1 é o normal
        */

        //player.GetComponent<PlayerController>().skin.GetComponent<Animator>().enabled = false;
    }

    private void OnDisable() {
        Time.timeScale = 1;
        GetComponent<CanvasGroup>().alpha = 0;
        GetComponent<CanvasGroup>().blocksRaycasts = false;

        //player.GetComponent<PlayerController>().skin.GetComponent<Animator>().enabled = true;
    }
}
